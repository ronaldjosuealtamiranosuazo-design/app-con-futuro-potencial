<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

const TABLAS    = ['trabajadores', 'empleadores'];
const SERVICIOS = ['jardineria', 'domestica'];
const DIAS      = ['Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab', 'Dom'];

function responder($datos, int $codigo = 200): never {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

function validar(array $in): array {
    $errores = [];
    $nombre = trim((string)($in['nombre'] ?? ''));
    $edad   = (int)($in['edad'] ?? 0);
    $correo = trim((string)($in['correo'] ?? ''));
    $tel    = trim((string)($in['telefono'] ?? ''));
    $dir    = trim((string)($in['direccion'] ?? ''));
    $desc   = trim((string)($in['descripcion'] ?? ''));
    $serv   = (string)($in['servicio'] ?? '');
    $dias   = array_values(array_intersect(DIAS, (array)($in['disponibilidad'] ?? [])));

    if ($nombre === '' || mb_strlen($nombre) > 100)             $errores[] = 'Escribe un nombre de hasta 100 caracteres.';
    if ($edad < 18 || $edad > 99)                               $errores[] = 'La edad debe estar entre 18 y 99 años.';
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL))            $errores[] = 'El correo no tiene un formato válido.';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $tel))            $errores[] = 'El teléfono debe tener entre 7 y 20 dígitos.';
    if ($dir === '' || mb_strlen($dir) > 200)                   $errores[] = 'Escribe una dirección de hasta 200 caracteres.';
    if ($desc === '' || mb_strlen($desc) > 500)                 $errores[] = 'La descripción es obligatoria (máximo 500 caracteres).';
    if (!in_array($serv, SERVICIOS, true))                      $errores[] = 'Elige un tipo de servicio.';
    if (!$dias)                                                 $errores[] = 'Marca al menos un día de disponibilidad.';

    if ($errores) responder(['ok' => false, 'errores' => $errores], 422);

    return [
        'nombre' => $nombre, 'edad' => $edad, 'servicio' => $serv,
        'disponibilidad' => implode(',', $dias), 'direccion' => $dir,
        'correo' => $correo, 'telefono' => $tel, 'descripcion' => $desc,
    ];
}

try {
    $pdo    = conectar();
    $accion = $_GET['accion'] ?? '';
    $tabla  = $_GET['tabla'] ?? '';

    if ($accion !== 'coincidencias' && !in_array($tabla, TABLAS, true)) {
        responder(['ok' => false, 'errores' => ['Tabla no válida.']], 400);
    }

    switch ($accion) {
        case 'listar':
            $servicio = $_GET['servicio'] ?? '';
            if (in_array($servicio, SERVICIOS, true)) {
                $st = $pdo->prepare("SELECT * FROM $tabla WHERE servicio = ? ORDER BY id DESC");
                $st->execute([$servicio]);
            } else {
                $st = $pdo->query("SELECT * FROM $tabla ORDER BY id DESC");
            }
            responder(['ok' => true, 'datos' => $st->fetchAll()]);

        case 'crear':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(['ok' => false, 'errores' => ['Usa POST.']], 405);
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $d  = validar($in);
            try {
                $st = $pdo->prepare(
                    "INSERT INTO $tabla (nombre, edad, servicio, disponibilidad, direccion, correo, telefono, descripcion)
                     VALUES (:nombre, :edad, :servicio, :disponibilidad, :direccion, :correo, :telefono, :descripcion)"
                );
                $st->execute($d);
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') responder(['ok' => false, 'errores' => ['Ese correo ya está registrado.']], 409);
                throw $e;
            }
            responder(['ok' => true, 'id' => (int)$pdo->lastInsertId()], 201);

        case 'eliminar':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(['ok' => false, 'errores' => ['Usa POST.']], 405);
            $in = json_decode(file_get_contents('php://input'), true) ?? [];
            $st = $pdo->prepare("DELETE FROM $tabla WHERE id = ?");
            $st->execute([(int)($in['id'] ?? 0)]);
            responder(['ok' => true, 'borrados' => $st->rowCount()]);

        case 'coincidencias':
            $emps  = $pdo->query('SELECT * FROM empleadores ORDER BY id DESC')->fetchAll();
            $trabs = $pdo->query('SELECT * FROM trabajadores')->fetchAll();
            $salida = [];
            foreach ($emps as $e) {
                $diasE = explode(',', $e['disponibilidad']);
                $candidatos = [];
                foreach ($trabs as $t) {
                    if ($t['servicio'] !== $e['servicio']) continue;
                    $comunes = array_values(array_intersect($diasE, explode(',', $t['disponibilidad'])));
                    if ($comunes) $candidatos[] = ['trabajador' => $t, 'dias_comunes' => $comunes];
                }
                usort($candidatos, fn($a, $b) => count($b['dias_comunes']) <=> count($a['dias_comunes']));
                $salida[] = ['empleador' => $e, 'candidatos' => $candidatos];
            }
            responder(['ok' => true, 'datos' => $salida]);

        default:
            responder(['ok' => false, 'errores' => ['Acción no válida.']], 400);
    }
} catch (Throwable $e) {
    error_log($e->getMessage());
    responder(['ok' => false, 'errores' => ['Error del servidor. Revisa la conexión a la base de datos.']], 500);
}
