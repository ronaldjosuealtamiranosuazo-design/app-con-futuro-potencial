# Manos a la obra: app de jardinería y trabajo doméstico

Aplicación web para que trabajadores (jardinería / doméstica) y empleadores se registren y se encuentren.

## Estructura
- `database.sql`  tablas `trabajadores` y `empleadores` (MySQL/MariaDB) con datos de ejemplo
- `config.php`    conexión PDO (usa DB_HOST, DB_NAME, DB_USER, DB_PASS o edita los valores)
- `api.php`       API JSON: listar, crear, eliminar y coincidencias (con validación)
- `index.html`, `style.css`, `app.js`  interfaz
- `python/emparejar.py`  empareja y exporta CSV

## Cómo ejecutarla
1. Importa la base: `mysql -u root -p < database.sql`
2. Ajusta usuario y contraseña en `config.php`.
3. En esta carpeta: `php -S localhost:8000` y abre http://localhost:8000
   (o copia la carpeta a `htdocs` de XAMPP / `www` de WAMP).
4. Python (opcional): `cd python && pip install -r requirements.txt && python emparejar.py --csv coincidencias.csv`

## Notas
- Las tablas incluyen el campo `servicio` (jardinería o doméstica) en ambos lados, necesario para emparejar.
- La disponibilidad se guarda como días: `Lun,Mie,Vie`.
- No tiene login: cualquiera puede borrar registros. Antes de publicarla en internet agrega autenticación
  y protege la acción `eliminar`; además, los datos personales (dirección, teléfono) deberían mostrarse solo a usuarios registrados.
