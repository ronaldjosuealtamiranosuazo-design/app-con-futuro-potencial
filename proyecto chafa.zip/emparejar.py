#!/usr/bin/env python3
"""
Empareja empleadores con trabajadores (mismo servicio y días en común)
y exporta el resultado a un archivo CSV.

Uso:
    pip install -r requirements.txt
    python emparejar.py                      # imprime en pantalla
    python emparejar.py --csv coincidencias.csv
    python emparejar.py --servicio jardineria

Variables de entorno opcionales: DB_HOST, DB_NAME, DB_USER, DB_PASS
"""
import argparse
import csv
import os
import sys

import mysql.connector


def conectar():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "127.0.0.1"),
        database=os.getenv("DB_NAME", "trabajos_hogar"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", ""),
    )


def cargar(cursor, tabla, servicio=None):
    sql = f"SELECT * FROM {tabla}"  # tabla es una constante interna, no viene del usuario
    params = ()
    if servicio:
        sql += " WHERE servicio = %s"
        params = (servicio,)
    cursor.execute(sql, params)
    return cursor.fetchall()


def emparejar(empleadores, trabajadores):
    resultados = []
    for e in empleadores:
        dias_e = set(e["disponibilidad"].split(","))
        for t in trabajadores:
            if t["servicio"] != e["servicio"]:
                continue
            comunes = dias_e & set(t["disponibilidad"].split(","))
            if comunes:
                resultados.append((e, t, sorted(comunes)))
    # Más días en común primero
    resultados.sort(key=lambda r: len(r[2]), reverse=True)
    return resultados


def main():
    ap = argparse.ArgumentParser(description="Empareja empleadores y trabajadores.")
    ap.add_argument("--servicio", choices=["jardineria", "domestica"])
    ap.add_argument("--csv", help="ruta del CSV de salida")
    args = ap.parse_args()

    try:
        conn = conectar()
    except mysql.connector.Error as err:
        sys.exit(f"No se pudo conectar a la base de datos: {err}")

    cur = conn.cursor(dictionary=True)
    empleadores = cargar(cur, "empleadores", args.servicio)
    trabajadores = cargar(cur, "trabajadores", args.servicio)
    cur.close()
    conn.close()

    pares = emparejar(empleadores, trabajadores)
    if not pares:
        print("No hay coincidencias todavía.")
        return

    for e, t, comunes in pares:
        print(f"[{e['servicio']}] {e['nombre']}  <->  {t['nombre']}  "
              f"({', '.join(comunes)})  Tel: {t['telefono']}")

    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["servicio", "empleador", "correo_empleador", "telefono_empleador",
                        "trabajador", "correo_trabajador", "telefono_trabajador", "dias_comunes"])
            for e, t, comunes in pares:
                w.writerow([e["servicio"], e["nombre"], e["correo"], e["telefono"],
                            t["nombre"], t["correo"], t["telefono"], " ".join(comunes)])
        print(f"\nCSV guardado en {args.csv}")


if __name__ == "__main__":
    main()
