"use strict";

const DIAS = ["Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom"];
const NOMBRE_SERVICIO = { jardineria: "Jardinería", domestica: "Trabajo doméstico" };

const TEXTOS = {
  trabajadores: {
    titulo: "Ofrezco mi trabajo",
    boton: "Publicar mi perfil",
    vacio: "Todavía no hay trabajadores. Publica el primer perfil.",
    exito: "Perfil publicado",
    descripcion: "Cuenta qué sabes hacer y tu experiencia",
    plural: "trabajador",
  },
  empleadores: {
    titulo: "Necesito contratar",
    boton: "Publicar mi solicitud",
    vacio: "Todavía no hay solicitudes. Publica la primera.",
    exito: "Solicitud publicada",
    descripcion: "Describe el trabajo que necesitas",
    plural: "empleador",
  },
};

/* ---------- Utilidades ---------- */
function esc(texto) {
  const d = document.createElement("div");
  d.textContent = String(texto ?? "");
  return d.innerHTML;
}

async function api(accion, tabla, { metodo = "GET", cuerpo, extra = "" } = {}) {
  const url = `api.php?accion=${accion}${tabla ? `&tabla=${tabla}` : ""}${extra}`;
  const opciones = { method: metodo, headers: {} };
  if (cuerpo) {
    opciones.headers["Content-Type"] = "application/json";
    opciones.body = JSON.stringify(cuerpo);
  }
  const resp = await fetch(url, opciones);
  const json = await resp.json().catch(() => ({ ok: false, errores: ["Respuesta inválida del servidor."] }));
  if (!resp.ok || !json.ok) throw json;
  return json;
}

let temporizadorAviso;
function avisar(mensaje) {
  const aviso = document.getElementById("aviso");
  aviso.textContent = mensaje;
  aviso.hidden = false;
  clearTimeout(temporizadorAviso);
  temporizadorAviso = setTimeout(() => (aviso.hidden = true), 2800);
}

/* ---------- Formularios ---------- */
function construirFormulario(tabla) {
  const t = TEXTOS[tabla];
  const form = document.getElementById(`form-${tabla}`);
  form.innerHTML = `
    <h2>${t.titulo}</h2>
    <ul class="errores" hidden></ul>

    <div class="campo">
      <label for="${tabla}-nombre">Nombre completo</label>
      <input id="${tabla}-nombre" name="nombre" maxlength="100" required autocomplete="name">
    </div>

    <div class="fila">
      <div class="campo">
        <label for="${tabla}-edad">Edad</label>
        <input id="${tabla}-edad" name="edad" type="number" min="18" max="99" required>
      </div>
      <div class="campo">
        <label for="${tabla}-servicio">Servicio</label>
        <select id="${tabla}-servicio" name="servicio" required>
          <option value="">Elige uno</option>
          <option value="jardineria">Jardinería</option>
          <option value="domestica">Trabajo doméstico</option>
        </select>
      </div>
    </div>

    <fieldset class="campo">
      <legend>Disponibilidad</legend>
      <div class="dias">
        ${DIAS.map(
          (d) => `<label><input type="checkbox" name="disponibilidad" value="${d}">${d}</label>`
        ).join("")}
      </div>
    </fieldset>

    <div class="campo">
      <label for="${tabla}-direccion">Dirección de casa</label>
      <input id="${tabla}-direccion" name="direccion" maxlength="200" required autocomplete="street-address">
    </div>

    <div class="fila">
      <div class="campo">
        <label for="${tabla}-correo">Correo</label>
        <input id="${tabla}-correo" name="correo" type="email" maxlength="120" required autocomplete="email">
      </div>
      <div class="campo">
        <label for="${tabla}-telefono">Teléfono</label>
        <input id="${tabla}-telefono" name="telefono" type="tel" maxlength="20" required autocomplete="tel">
      </div>
    </div>

    <div class="campo">
      <label for="${tabla}-descripcion">Descripción</label>
      <textarea id="${tabla}-descripcion" name="descripcion" maxlength="500" required
        placeholder="${t.descripcion}"></textarea>
    </div>

    <button class="boton" type="submit">${t.boton}</button>
  `;

  form.addEventListener("submit", (e) => enviarFormulario(e, tabla));
}

async function enviarFormulario(evento, tabla) {
  evento.preventDefault();
  const form = evento.currentTarget;
  const caja = form.querySelector(".errores");
  const boton = form.querySelector("button[type=submit]");
  const datos = new FormData(form);

  const cuerpo = {
    nombre: datos.get("nombre"),
    edad: datos.get("edad"),
    servicio: datos.get("servicio"),
    disponibilidad: datos.getAll("disponibilidad"),
    direccion: datos.get("direccion"),
    correo: datos.get("correo"),
    telefono: datos.get("telefono"),
    descripcion: datos.get("descripcion"),
  };

  caja.hidden = true;
  boton.disabled = true;
  try {
    await api("crear", tabla, { metodo: "POST", cuerpo });
    form.reset();
    avisar(TEXTOS[tabla].exito);
    cargarLista(tabla);
  } catch (err) {
    const errores = err.errores || ["No se pudo conectar con el servidor."];
    caja.innerHTML = errores.map((m) => `<li>${esc(m)}</li>`).join("");
    caja.hidden = false;
  } finally {
    boton.disabled = false;
  }
}

/* ---------- Listas ---------- */
function tarjeta(fila, tabla, conBorrar = true) {
  const dias = fila.disponibilidad.split(",").join(" · ");
  return `
    <article class="tarjeta" data-servicio="${esc(fila.servicio)}">
      <div class="tarjeta-cab">
        <div>
          <h3>${esc(fila.nombre)} <span class="edad">${esc(fila.edad)} años</span></h3>
          <span class="etiqueta">${esc(NOMBRE_SERVICIO[fila.servicio])}</span>
        </div>
        ${
          conBorrar
            ? `<button class="boton boton-borrar" data-borrar="${esc(fila.id)}" data-tabla="${tabla}"
                aria-label="Eliminar a ${esc(fila.nombre)}">Eliminar</button>`
            : ""
        }
      </div>
      <p>${esc(fila.descripcion)}</p>
      <div class="datos">
        <span><strong>Disponible:</strong> ${esc(dias)}</span>
        <span><strong>Dirección:</strong> ${esc(fila.direccion)}</span>
        <span><strong>Correo:</strong> <a href="mailto:${esc(fila.correo)}">${esc(fila.correo)}</a></span>
        <span><strong>Teléfono:</strong> <a href="tel:${esc(fila.telefono)}">${esc(fila.telefono)}</a></span>
      </div>
    </article>`;
}

async function cargarLista(tabla) {
  const contenedor = document.getElementById(`lista-${tabla}`);
  const servicio = document.getElementById(`filtro-${tabla}`).value;
  try {
    const { datos } = await api("listar", tabla, {
      extra: servicio ? `&servicio=${encodeURIComponent(servicio)}` : "",
    });
    contenedor.innerHTML = datos.length
      ? datos.map((f) => tarjeta(f, tabla)).join("")
      : `<div class="vacio">${TEXTOS[tabla].vacio}</div>`;
  } catch (err) {
    contenedor.innerHTML = `<div class="vacio">${esc((err.errores || ["Error de conexión."])[0])}</div>`;
  }
}

async function cargarCoincidencias() {
  const contenedor = document.getElementById("lista-coincidencias");
  try {
    const { datos } = await api("coincidencias");
    if (!datos.length) {
      contenedor.innerHTML = `<div class="vacio">Aún no hay solicitudes de empleadores para emparejar.</div>`;
      return;
    }
    contenedor.innerHTML = datos
      .map(({ empleador, candidatos }) => `
        <section class="grupo">
          <h2>Para ${esc(empleador.nombre)}: ${esc(NOMBRE_SERVICIO[empleador.servicio])}</h2>
          ${tarjeta(empleador, "empleadores", false)}
          <div class="grupo-candidatos">
            ${
              candidatos.length
                ? candidatos
                    .map(
                      (c) => `${tarjeta(c.trabajador, "trabajadores", false)
                        .replace("</article>",
                          `<div class="dias-comunes">Coinciden en: ${esc(c.dias_comunes.join(" · "))}</div></article>`)}`
                    )
                    .join("")
                : `<div class="vacio">Ningún trabajador coincide todavía en servicio y días.</div>`
            }
          </div>
        </section>`)
      .join("");
  } catch (err) {
    contenedor.innerHTML = `<div class="vacio">${esc((err.errores || ["Error de conexión."])[0])}</div>`;
  }
}

/* ---------- Eventos ---------- */
document.addEventListener("click", async (e) => {
  const borrar = e.target.closest("[data-borrar]");
  if (!borrar) return;
  if (!confirm("¿Eliminar este registro? No se puede deshacer.")) return;
  const tabla = borrar.dataset.tabla;
  try {
    await api("eliminar", tabla, { metodo: "POST", cuerpo: { id: Number(borrar.dataset.borrar) } });
    avisar("Registro eliminado");
    cargarLista(tabla);
  } catch (err) {
    avisar((err.errores || ["No se pudo eliminar."])[0]);
  }
});

document.querySelectorAll(".filtro select").forEach((s) =>
  s.addEventListener("change", () => cargarLista(s.dataset.tabla))
);

document.querySelectorAll(".pestanas button").forEach((boton) =>
  boton.addEventListener("click", () => {
    document.querySelectorAll(".pestanas button").forEach((b) => {
      const activa = b === boton;
      b.classList.toggle("activa", activa);
      b.setAttribute("aria-selected", activa);
    });
    document.querySelectorAll(".panel").forEach((p) => (p.hidden = true));
    document.getElementById(`panel-${boton.dataset.panel}`).hidden = false;
    if (boton.dataset.panel === "coincidencias") cargarCoincidencias();
    else cargarLista(boton.dataset.panel);
  })
);

/* ---------- Inicio ---------- */
["trabajadores", "empleadores"].forEach(construirFormulario);
cargarLista("trabajadores");
