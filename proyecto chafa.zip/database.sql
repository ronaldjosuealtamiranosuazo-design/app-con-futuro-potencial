-- Base de datos: Trabajos de jardinería y domésticos
CREATE DATABASE IF NOT EXISTS trabajos_hogar
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE trabajos_hogar;

-- Personas que ofrecen su trabajo
CREATE TABLE IF NOT EXISTS trabajadores (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  edad           TINYINT UNSIGNED NOT NULL,
  servicio       ENUM('jardineria','domestica') NOT NULL,
  disponibilidad VARCHAR(40)  NOT NULL,          -- ej: "Lun,Mie,Vie"
  direccion      VARCHAR(200) NOT NULL,
  correo         VARCHAR(120) NOT NULL UNIQUE,
  telefono       VARCHAR(20)  NOT NULL,
  descripcion    VARCHAR(500) NOT NULL,
  creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_edad_trabajador CHECK (edad BETWEEN 18 AND 99)
) ENGINE=InnoDB;

-- Personas que buscan contratar
CREATE TABLE IF NOT EXISTS empleadores (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  edad           TINYINT UNSIGNED NOT NULL,
  servicio       ENUM('jardineria','domestica') NOT NULL,
  direccion      VARCHAR(200) NOT NULL,
  correo         VARCHAR(120) NOT NULL UNIQUE,
  telefono       VARCHAR(20)  NOT NULL,
  disponibilidad VARCHAR(40)  NOT NULL,
  descripcion    VARCHAR(500) NOT NULL,
  creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_edad_empleador CHECK (edad BETWEEN 18 AND 99)
) ENGINE=InnoDB;

CREATE INDEX idx_trab_servicio ON trabajadores (servicio);
CREATE INDEX idx_emp_servicio  ON empleadores (servicio);

-- Datos de ejemplo
INSERT INTO trabajadores (nombre, edad, servicio, disponibilidad, direccion, correo, telefono, descripcion) VALUES
('Marta López', 34, 'domestica', 'Lun,Mar,Mie,Jue,Vie', 'Barrio Monseñor Lezcano, Managua', 'marta@example.com', '8888-1111', 'Limpieza general, lavado y planchado. 8 años de experiencia.'),
('Carlos Ruiz', 41, 'jardineria', 'Sab,Dom,Mie', 'Altamira, Managua', 'carlos@example.com', '8777-2222', 'Poda, césped y diseño de jardines pequeños. Llevo mis herramientas.');

INSERT INTO empleadores (nombre, edad, servicio, direccion, correo, telefono, disponibilidad, descripcion) VALUES
('Ana Pérez', 38, 'domestica', 'Los Robles, Managua', 'ana@example.com', '8555-3333', 'Mar,Jue,Vie', 'Busco ayuda con la limpieza de la casa tres días por semana.'),
('Luis Gómez', 52, 'jardineria', 'Villa Fontana, Managua', 'luis@example.com', '8444-4444', 'Sab,Dom', 'Necesito mantenimiento mensual del jardín y poda de árboles.');
